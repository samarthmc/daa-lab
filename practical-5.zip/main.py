import time

def knapsack(weights, values, capacity):
    n = len(weights)

    # DP table
    dp = [[0 for _ in range(capacity + 1)] for _ in range(n + 1)]

    # Build DP table
    for i in range(1, n + 1):
        for w in range(1, capacity + 1):

            if weights[i - 1] <= w:
                # Include or exclude the current item
                dp[i][w] = max(
                    values[i - 1] + dp[i - 1][w - weights[i - 1]],
                    dp[i - 1][w]
                )
            else:
                # Cannot include the current item
                dp[i][w] = dp[i - 1][w]

    return dp[n][capacity]


# -------------------------------
# User Input
# -------------------------------

n = int(input("Enter number of items: "))

weights = []
values = []

print("\nEnter weight and value of each item:")

for i in range(n):
    weight = int(input(f"Weight of item {i + 1}: "))
    value = int(input(f"Value of item {i + 1}: "))

    weights.append(weight)
    values.append(value)

capacity = int(input("\nEnter maximum capacity of knapsack: "))


# -------------------------------
# Measure execution time
# -------------------------------

start_time = time.perf_counter()

max_value = knapsack(weights, values, capacity)

end_time = time.perf_counter()

execution_time = end_time - start_time


# -------------------------------
# Output
# -------------------------------

print("\n========== RESULT ==========")
print("Weights:", weights)
print("Values :", values)
print("Capacity:", capacity)
print("Maximum value:", max_value)
print(f"Execution time: {execution_time:.9f} seconds")
