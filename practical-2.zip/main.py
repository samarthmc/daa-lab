import time

# Linear Search Function
def linear_search(arr, key):
    for i in range(len(arr)):
        if arr[i] == key:
            return i
    return -1

# User Input
n = int(input("Enter the number of elements: "))

arr = []
print("Enter the elements:")
for i in range(n):
    arr.append(int(input()))

key = int(input("Enter the element to search: "))

# Start Time
start_time = time.perf_counter()

# Perform Linear Search
result = linear_search(arr, key)

# End Time
end_time = time.perf_counter()

# Display Result
if result != -1:
    print(f"Element found at index {result}")
else:
    print("Element not found")

# Execution Time
execution_time = end_time - start_time
print(f"Execution Time: {execution_time:.10f} seconds")

# Time Complexity
print("\nTime Complexity:")
print("Best Case   : O(1)")
print("Average Case: O(n)")
print("Worst Case  : O(n)")

# Space Complexity
print("Space Complexity: O(1)")