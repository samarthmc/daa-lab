import time

# Recursive function
def factorial(n):
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)


# User input
n = int(input("Enter a number: "))

# Measure execution time
start_time = time.perf_counter()

result = factorial(n)

end_time = time.perf_counter()

# Calculate execution time
execution_time = end_time - start_time

# Output
print("\nResult:", result)
print("Execution Time: {:.10f} seconds".format(execution_time))
print("Time Complexity: O(n)")
print("Space Complexity: O(n)")