```python
import time

# Iterative function to calculate factorial
def iterative_factorial(n):
    result = 1

    for i in range(1, n + 1):
        result *= i

    return result


# Get input from user
n = int(input("Enter a positive integer: "))

if n < 0:
    print("Please enter a non-negative integer.")
else:
    # Start execution timer
    start_time = time.perf_counter()

    # Call iterative function
    result = iterative_factorial(n)

    # End execution timer
    end_time = time.perf_counter()

    # Calculate execution time
    execution_time = end_time - start_time

    # Display results
    print("\nResult:", result)
    print("Time Complexity: O(n)")
    print("Space Complexity: O(1)")
    print("Execution Time:", execution_time, "seconds")
```

### Example Output

```text
Enter a positive integer: 5

Result: 120
Time Complexity: O(n)
Space Complexity: O(1)
Execution Time: 0.0000021 seconds
```

### Explanation

* **Iterative function:** Uses a `for` loop instead of recursion.
* **User input:** The value of `n` is entered by the user.
* **Time complexity:** `O(n)` because the loop runs `n` times.
* **Space complexity:** `O(1)` because only a fixed amount of extra memory is used.
* **Execution time:** `time.perf_counter()` measures how long the function actually takes to execute.

For very small inputs, the execution time may appear extremely small or vary between runs because of computer/system overhead.
