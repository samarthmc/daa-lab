import time

# User input
coins = list(map(int, input("Enter coin denominations (space-separated): ").split()))
amount = int(input("Enter the amount: "))

# Start execution timer
start_time = time.perf_counter()

# Dynamic Programming approach
dp = [float('inf')] * (amount + 1)
dp[0] = 0

for i in range(1, amount + 1):
    for coin in coins:
        if coin <= i:
            dp[i] = min(dp[i], dp[i - coin] + 1)

# End execution timer
end_time = time.perf_counter()

# Result
if dp[amount] == float('inf'):
    print("Coin change is not possible.")
else:
    print("Minimum number of coins:", dp[amount])

execution_time = end_time - start_time
print(f"Execution time: {execution_time:.9f} seconds")

# Complexity
print("Time Complexity: O(amount × number_of_coins)")
print("Space Complexity: O(amount)")