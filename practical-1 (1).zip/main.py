import time

# Bubble Sort Function
def bubble_sort(arr):
    n = len(arr)

    for i in range(n - 1):
        swapped = False

        for j in range(n - i - 1):
            if arr[j] > arr[j + 1]:
                # Swap elements
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True

        # If no swapping occurs, array is already sorted
        if not swapped:
            break

# User Input
n = int(input("Enter the number of elements: "))

arr = []
print("Enter the elements:")
for i in range(n):
    arr.append(int(input()))

# Measure Execution Time
start_time = time.perf_counter()

bubble_sort(arr)

end_time = time.perf_counter()

# Output
print("\nSorted Array:")
print(arr)

print(f"\nExecution Time: {end_time - start_time:.10f} seconds")

# Time Complexity Information
print("\nTime Complexity:")
print("Best Case    : O(n)")
print("Average Case : O(n²)")
print("Worst Case   : O(n²)")
print("Space Complexity: O(1)")
