import time


def matrix_chain_order(p):
    n = len(p) - 1

    # Create DP table
    dp = [[0 for _ in range(n)] for _ in range(n)]

    # Chain length
    for length in range(2, n + 1):

        for i in range(n - length + 1):
            j = i + length - 1

            dp[i][j] = float('inf')

            # Find minimum multiplication cost
            for k in range(i, j):
                cost = (
                    dp[i][k]
                    + dp[k + 1][j]
                    + p[i] * p[k + 1] * p[j + 1]
                )

                if cost < dp[i][j]:
                    dp[i][j] = cost

    return dp[0][n - 1]


# -----------------------------------
# User Input
# -----------------------------------

n = int(input("Enter number of matrices: "))

dimensions = []

print("\nEnter dimensions:")

for i in range(n):
    rows = int(input(f"Enter rows of Matrix {i + 1}: "))

    if i == 0:
        dimensions.append(rows)

    columns = int(input(f"Enter columns of Matrix {i + 1}: "))
    dimensions.append(columns)


# -----------------------------------
# Check whether multiplication is possible
# -----------------------------------

possible = True

for i in range(n - 1):
    if dimensions[i + 1] != dimensions[i + 1]:
        possible = False
        break


# -----------------------------------
# Calculate execution time
# -----------------------------------

start_time = time.perf_counter()

minimum_cost = matrix_chain_order(dimensions)

end_time = time.perf_counter()

execution_time = end_time - start_time


# -----------------------------------
# Output
# -----------------------------------

print("\n========== RESULT ==========")
print("Number of matrices:", n)
print("Dimensions:", dimensions)
print("Minimum number of scalar multiplications:", minimum_cost)
print(f"Execution time: {execution_time:.9f} seconds")

print("\n========== COMPLEXITY ==========")
print("Time Complexity: O(n^3)")
print("Space Complexity: O(n^2)")
